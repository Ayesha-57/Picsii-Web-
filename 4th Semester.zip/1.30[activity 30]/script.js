let input = Number(prompt("Enter your age: "))
const value = 90;
ageleft = 90 - input;
monthsleft = ageleft *12;
daysleft = monthsleft * 365;
console.log(`You have ${daysleft}days ${monthsleft}months ${ageleft}years left`);