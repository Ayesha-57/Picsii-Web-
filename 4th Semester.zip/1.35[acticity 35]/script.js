let array = ['Amna', 'Maham', 'Sara', 'Zeeshan', 'Saad', 'Ali','Rabbia']
let guest = prompt("Please tell your name so That i can check my list whther you are in it or not: ")
if(array.includes(guest))
{
    alert(`Welcome at my home ${guest}`)
}
else{
    alert(`You are not allowed to enter my permises`)
}