function main(){
    // your code goes here!
    putBeeper()
    for(let i = 0; i <7; i++)
    {
        move()   
        turnLeft()
        move()
        putBeeper()
        turnRight()
    }
     }


     function main(){
    // your code goes here!
    putBeeper()
    for(let i = 0; i <3; i++)
    {
        move()   
        move()
        putBeeper()
    }
    move()
    turnLeft()
    move()
    putBeeper()
    turnLeft()
    for(let i = 0; i <3; i++)
    {
        move()   
        move()
        putBeeper()
    }
     move()
    turnRight()
    move()
    putBeeper()
    turnRight()
    for(let i = 0; i <3; i++)
    {
        move()   
        move()
        putBeeper()
    }
     move()
    turnLeft()
    move()
    putBeeper()
    turnLeft()
     for(let i = 0; i <3; i++)
    {
        move()   
        move()
        putBeeper()
    }
    move()
    turnRight()
    move()
    putBeeper()
    turnRight()
     for(let i = 0; i <3; i++)
    {
        move()   
        move()
        putBeeper()
    }
    move()
    turnLeft()
    move()
    putBeeper()
    turnLeft()
     for(let i = 0; i <3; i++)
    {
        move()   
        move()
        putBeeper()
    }
     move()
    turnRight()
    move()
    putBeeper()
    turnRight()
     for(let i = 0; i <3; i++)
    {
        move()   
        move()
        putBeeper()
    }
    move()
    turnLeft()
    move()
    putBeeper()
    turnLeft()
     for(let i = 0; i <3; i++)
    {
        move()   
        move()
        putBeeper()
    }
     }