let name = prompt("Enter your name: ")
let friendName = prompt("Enter your friend name: ")
// Example: Generating a random number between 0 and 1
let randomNum = Math.random(); 
let min = 1;
let max = 100;
let randomInt = Math.ceil(Math.random() * (max - min + 1)) + min; 
alert(`Your friendship score is ${randomInt}%`)
if(randomInt >= 80 && randomInt <= 100)
{
    alert("Your friendship is marvelous")
}
else if(randomInt >= 60 && randomInt <=79)
{
    alert("Your friendship is very good")
}
else if(randomInt >=40 && randomInt >=59)
{
    alert("Your friendship is not bad")
}
else{
    alert("Your friendship is very bad")
}