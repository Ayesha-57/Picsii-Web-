let maxLength = 240;
let input = prompt(`Enter your text ${maxLength} characters` );
let inputlength = input.length;
let char = maxLength = inputlength;

if (userInput !== null) {
    // Get the length of the input
    let inputLength = userInput.length;

    // Calculate remaining characters
    let remainingChars = MAX_LENGTH - inputLength;

    // Show the results in an alert
    alert(`You entered ${inputLength} characters.\nYou have ${remainingChars} characters remaining.`);
} else {
    alert("You cancelled the input.");
}