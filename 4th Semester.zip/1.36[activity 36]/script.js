let number = 1;

function fizzbuzz() {
    if (number % 3 === 0 && number % 5 === 0) {
        console.log("FizzBuzz");
    } else if (number % 3 === 0) {
        console.log("Fizz");
    } else if (number % 5 === 0) {
        console.log("Buzz");
    } else {
        console.log(number);
    }

    number++;
}
for (let i = 1; i <= 15; i++) {
    fizzbuzz();
}
