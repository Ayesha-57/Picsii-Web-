let input = prompt("Enter your name: ");
let part = input.slice(0,1);
let part2 = input.slice(1,6);
let input2 = part.toUpperCase();
alert(`Hello ${input2}${part2}`);