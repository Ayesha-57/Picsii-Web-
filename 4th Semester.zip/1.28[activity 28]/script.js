let doagage = Number(prompt("Enter your dog age: "));
let humanage = (doagage - 2);
humanage = (humanage *4) +21;
alert(humanage);