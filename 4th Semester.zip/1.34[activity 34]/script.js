let year = Number(prompt("Enter year"))
if(year % 400 == 0)
{
    console.log("It is a leap year")
    }
else if(year %100 == 0){
    console.log("It is not a leap year")
}
 else if(year % 4 == 0){
            console.log("Year is Leap year")
        }
else{
    console.log("It is not a leap year")
}