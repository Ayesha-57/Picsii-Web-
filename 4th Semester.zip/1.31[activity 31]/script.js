let height = Number(prompt("enter height in meters:"))
let weight = Number(prompt("Enter weight in kilograms: "))
let height2 = height*height;
let BMI = weight / height2
console.log(`BMI is ${BMI}`)
